Run the following commands : 
minikube start
kubectl apply -f redis-deployment.yaml
kubectl apply -f redis-service.yaml
kubectl apply -f url-shortener-deployment.yaml
kubectl apply -f url-shortener-service.yaml
kubectl apply -f url-shortener-hpa.yaml
kubectl apply -f url-shortener-ingress.yaml
kubectl apply -f url-shortener-secret.yaml
kubectl get pods
kubectl get svc
kubectl get deployments
kubectl port-forward service/url-shortener-service 8080:80
curl http://localhost:8080
